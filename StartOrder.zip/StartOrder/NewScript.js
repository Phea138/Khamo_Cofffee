let keypadMode = null; // "TABLE" or "PAYMENT"

        // let selectedTable = localStorage.getItem("selectedTable");
        // document.getElementById("showTable").innerText = selectedTable;
        let selectedTable = null;

    //     window.onload = function () {
    //     const savedTable = localStorage.getItem("selectedTable");

    //     if (savedTable) {
    //     selectedTable = savedTable;
    //     startOrderScreen();
    //    }
    // };

    window.onload = function () {

    const savedTable = localStorage.getItem("selectedTable");

    if (savedTable) {
        selectedTable = savedTable;
        startOrderScreen();
    } else {
        openTableKeypad();
    }
};

function openTableKeypad(){
    keypadMode = "TABLE";
    currentInput = null;

    keypad.style.display = "flex";
    display.innerText = "0";
}


    //     if (!selectedTable) {
    //    alert("No table selected");
    //    window.location.href = "../Navbar/DineIn.html";
    //     } 
      
    function quickTable(number){
    document.getElementById("tableInput").value = number;
}


function confirmTable(){
    const value = document.getElementById("tableInput").value;

    if(!value){
        alert("Please enter table number");
        return;
    }

    selectedTable = "Table " + value;

    localStorage.setItem("selectedTable", selectedTable);

    startOrderScreen();
}

function startOrderScreen(){
    document.getElementById("orderContainer").style.display = "flex";
    document.getElementById("showTable").innerText = selectedTable;
    loadExistingOrder(); 
}



    //       function loadExistingOrder() {
    //   const orders = JSON.parse(localStorage.getItem("dineInOrders")) || [];

    //    const existing = orders.find(o => o.table === selectedTable);

    //    if (!existing) return;

    //     existing.items.forEach(i => {
    //     addItem(i.name, i.size, parseFloat(i.price));
    //    });
    //  }
    //  loadExistingOrder();


             let products = [];

            // let selectedTable = null;

          function selectTable(table){

              selectedTable = table;
              document.getElementById("currentTable").innerText =
              "Selected: " + table;
            }

        const itemContainer = document.querySelector(".item");

        // function showCategory(category) {
        //     itemContainer.innerHTML = "";

        //     menu[category].forEach(item => {
        //         const btn = document.createElement("button");
        //         btn.innerText = `${item.name} ${item.size}`;
        //         btn.onclick = () => addItem(item.name, item.size, item.price);
        //         itemContainer.appendChild(btn);
        //     });
        // }

        function showCategory(category) {
    itemContainer.innerHTML = "";

    const filtered = products.filter(p => p.category === category);

    filtered.forEach(product => {
        const btn = document.createElement("button");
        // btn.innerText = `${product.name} ${product.size}\n$${product.price}`;
        btn.innerText = `${product.name} ${product.size}`;
        btn.onclick = () => addItem(product.name, product.size, parseFloat(product.price));
        // btn.onclick = () => addItem(product.name, product.size);
        itemContainer.appendChild(btn);
    });
}


        // loadproducts form aip and sql
             async function loadProducts() {
                 try {
                  const response = await fetch("http://localhost:3000/api/products");
                   products = await response.json();
                   console.log("Products loaded:", products);
               } catch (error) {
                   console.error("Error loading products:", error);
                   }
                }
              loadProducts();


        function addItem(name, size, unitPrice) {
            let table = document.getElementById('table-item');
            let row = table.insertRow();

            row.insertCell(0).innerText = name;
            row.insertCell(1).innerText = size;

            // Qty (editable)
            let qtyCell = row.insertCell(2);
            qtyCell.innerText = 1;
            qtyCell.contentEditable = "true";

            // Price
            row.insertCell(3).innerText = unitPrice.toFixed(2);

            // Discount (editable)
            let discountCell = row.insertCell(4);
            discountCell.innerText = 0;
            discountCell.contentEditable = "true";

            // Unit total
            let totalCell = row.insertCell(5);
            totalCell.innerText = unitPrice.toFixed(2);

            qtyCell.oninput = discountCell.oninput = function () {
                calculateRow(row);
                calculateTotal();
            };

            // Delete button
            let deleteCell = row.insertCell(6);
            const btncancel = document.createElement("img");
            btncancel.src = "../img/delete_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png";
            btncancel.style.cursor = "pointer";
            btncancel.onclick = function () {
                row.remove();
                calculateTotal();
            };
            deleteCell.appendChild(btncancel);

            calculateTotal();
        }

        function calculateRow(row) {
            let price = parseFloat(row.cells[3].innerText);
            let qty = parseFloat(row.cells[2].innerText) || 1;
            let discount = parseFloat(row.cells[4].innerText) || 0;

            let total = price * qty;
            total -= total * discount / 100;

            row.cells[5].innerText = total.toFixed(2);
        }

        // function calculateTotal() {
        //     let rows = document.querySelectorAll("#table-item tr");
        //     let subTotal = 0;
        //     let totalDiscount = 0;

        //     rows.forEach(row => {
        //         let price = parseFloat(row.cells[3].innerText);
        //         let qty = parseFloat(row.cells[2].innerText) || 1;
        //         let discount = parseFloat(row.cells[4].innerText) || 0;

        //         let rowTotal = price * qty;
        //         let rowDiscount = rowTotal * discount / 100;

        //         subTotal += rowTotal;
        //         totalDiscount += rowDiscount;
        //     });

        //     document.getElementById("subTotal").innerText = subTotal.toFixed(2);
        //     document.getElementById("discount").innerText = totalDiscount.toFixed(2);
        //     let totalUSD = (subTotal - totalDiscount);
        //     document.getElementById("totalPriceUSD").innerText = totalUSD.toFixed(2);
        //     let totalKH = totalUSD * 4000;
        //     document.getElementById('totalPriceKh').innerText = totalKH.toLocaleString();

        //     let cashKH = parseFloat(document.getElementById('cashKHPayment').value) || 0;
        //     let cashUSD = parseFloat(document.getElementById('cashUSDPayment').value) || 0;
        //     let change = 0;

        //     if (cashKH > 0) {
        //         change = cashKH - totalKH;
        //     } else if (cashUSD > 0) {
        //         change = cashUSD - totalUSD;
        //     }

        //     document.getElementById("change").innerText = change.toLocaleString();
        // }
        function calculateTotal() {
    let rows = document.querySelectorAll("#table-item tr");
    let subTotal = 0;
    let totalDiscount = 0;

    rows.forEach(row => {
        let price = parseFloat(row.cells[3].innerText);
        let qty = parseFloat(row.cells[2].innerText) || 1;
        let discount = parseFloat(row.cells[4].innerText) || 0;

        let rowTotal = price * qty;
        let rowDiscount = rowTotal * discount / 100;

        subTotal += rowTotal;
        totalDiscount += rowDiscount;
    });

    let totalUSD = subTotal - totalDiscount;
    let totalKH = totalUSD * 4000;

    document.getElementById("subTotal").innerText = subTotal.toFixed(2);
    document.getElementById("discount").innerText = totalDiscount.toFixed(2);
    document.getElementById("totalPriceUSD").innerText = totalUSD.toFixed(2);
    document.getElementById("totalPriceKh").innerText = totalKH.toLocaleString();

    // ===== PAYMENT =====
    let cashKH = parseFloat(document.getElementById('cashKHPayment').value) || 0;
    let cashUSD = parseFloat(document.getElementById('cashUSDPayment').value) || 0;

    // Convert all payment to USD
    // let paidUSD = cashUSD + (cashKH / 4000);

    // let changeUSD = paidUSD - totalUSD;
    // if (changeUSD < 0) changeUSD = 0;

    // let changeKH = changeUSD * 4000;

    // document.getElementById("changeUSD").innerText = changeUSD.toFixed(2);
    // document.getElementById("changeKH").innerText = changeKH.toLocaleString();

    // Convert all payment to USD
let paidUSD = cashUSD + (cashKH / 4000);

// DEFAULT change = 0
let changeUSD = 0;
let changeKH = 0;

// Only calculate change if payment is enough
if (paidUSD >= totalUSD && totalUSD > 0) {
    changeUSD = paidUSD - totalUSD;
    changeKH = changeUSD * 4000;
}

document.getElementById("changeUSD").innerText = changeUSD.toFixed(2);
document.getElementById("changeKH").innerText = changeKH.toLocaleString();
}

        // Add input listeners for payment fields
        document.getElementById('cashKHPayment').addEventListener('input', calculateTotal);
        document.getElementById('cashUSDPayment').addEventListener('input', calculateTotal);
 

        // add one function
        function hasItemsInCart() {
    return document.querySelectorAll("#table-item tr").length > 0;
    }

       function isOrderUnpaid() {
    const rows = document.querySelectorAll("#table-item tr");
    if (rows.length === 0) return false;

    const totalUSD = parseFloat(
        document.getElementById("totalPriceUSD").innerText
    ) || 0;

    const cashKH = parseFloat(document.getElementById("cashKHPayment").value) || 0;
    const cashUSD = parseFloat(document.getElementById("cashUSDPayment").value) || 0;

    const paidUSD = cashUSD + (cashKH / 4000);

    return totalUSD > 0 && paidUSD < totalUSD;
}



// one function
// function saveUnpaidOrder() {
//     const rows = document.querySelectorAll("#table-item tr");
//     if (rows.length === 0) return;

//     const items = [];

//     rows.forEach(row => {
//         const c = row.cells;
//         items.push({
//             name: c[0].innerText,
//             size: c[1].innerText,
//             qty: c[2].innerText,
//             price: c[3].innerText,
//             discount: c[4].innerText,
//             total: c[5].innerText
//         });
//     });

//     const dineInOrders = JSON.parse(localStorage.getItem("dineInOrders")) || [];

//     dineInOrders.push({
//         id: Date.now(),
//         table: selectedTable,
//         status: "UNPAID",
//         items: items
//     });

//     localStorage.setItem("dineInOrders", JSON.stringify(dineInOrders));
// }
function saveUnpaidOrder() {
    const rows = document.querySelectorAll("#table-item tr");
    if (rows.length === 0) return;

    const items = [];

    rows.forEach(row => {
        const c = row.cells;
        items.push({
            name: c[0].innerText,
            size: c[1].innerText,
            qty: c[2].innerText,
            price: c[3].innerText,
            discount: c[4].innerText,
            total: c[5].innerText
        });
    });

    let dineInOrders = JSON.parse(localStorage.getItem("dineInOrders")) || [];

    dineInOrders = dineInOrders.filter(o => o.table !== selectedTable);

    const totalUSD = parseFloat(document.getElementById("totalPriceUSD").innerText) || 0;

    const cashKH = parseFloat(document.getElementById("cashKHPayment").value) || 0;
    const cashUSD = parseFloat(document.getElementById("cashUSDPayment").value) || 0;

    const paidUSD = cashUSD + (cashKH / 4000);

    let status = "UNPAID";
    if (paidUSD >= totalUSD && totalUSD > 0) {
        status = "PAID";
    }

    dineInOrders.push({
        id: Date.now(),
        table: selectedTable,
        status: status,
        total: totalUSD.toFixed(2),
        time: new Date().toLocaleTimeString(),
        items: items
    });

    localStorage.setItem("dineInOrders", JSON.stringify(dineInOrders));
}


// one funtion 
function loadExistingOrder() {
    const orders = JSON.parse(localStorage.getItem("dineInOrders")) || [];

    const existing = orders.find(o => o.table === selectedTable);

    if (!existing) return;

    existing.items.forEach(i => {
        addItem(i.name, i.size, parseFloat(i.price));

        const rows = document.querySelectorAll("#table-item tr");
        const lastRow = rows[rows.length - 1];

        lastRow.cells[2].innerText = i.qty;
        lastRow.cells[4].innerText = i.discount;

        calculateRow(lastRow);
    });

    calculateTotal();
}



  //one funtion to save order to dinein
//   function confirmOrder(){
//     if(!selectedTable){
//         alert("Please select table first");
//         return;
//     }

//     const rows = document.querySelectorAll("#table-item tr");
//     if(rows.length === 0){
//         alert("No products selected");
//         return;
//     }

//     let items = [];
//     rows.forEach(row=>{
//         items.push({
//             name: row.cells[0].innerText,
//             size: row.cells[1].innerText,
//             qty: row.cells[2].innerText,
//             price: row.cells[3].innerText,
//             discount: row.cells[4].innerText,
//             total: row.cells[5].innerText
//         });
//     });

//     let orders = JSON.parse(localStorage.getItem("dineInOrders")) || [];

//     // overwrite same table
//     orders = orders.filter(o => o.table !== selectedTable);

//     orders.push({
//         table: selectedTable,
//         items,
//         paid: false,
//         time: new Date().toLocaleTimeString()
//     });

//     localStorage.setItem("dineInOrders", JSON.stringify(orders));

//     alert("Order saved to " + selectedTable);
// }

// print reciept simple
// function printReceipt(){
//     let receipt = "==== RECEIPT ====\n";
//     receipt += selectedTable + "\n\n";

//     document.querySelectorAll("#table-item tr").forEach(row=>{
//         receipt +=
//             `${row.cells[0].innerText} ${row.cells[1].innerText}  x${row.cells[2].innerText}  $${row.cells[5].innerText}\n`;
//     });

//     receipt += "\nThank you!";
//     const win = window.open("", "", "width=300,height=500");
//     win.document.write("<pre>"+receipt+"</pre>");
//     win.print();
// }




//  ============================================================================================
// Script of code for keyboard point of screen  
//     const KhpaymentInput = document.getElementById('cashKHPayment');
    
//     const keypad = document.getElementById('keypad');
//     const display = document.getElementById('display');

// KhpaymentInput.addEventListener('click', () => {
//     keypad.style.display = 'flex';
//     display.innerText = KhpaymentInput.value || '0';
// });

// document.querySelectorAll('.key').forEach(key => {
//     key.addEventListener('click', () => {
//         let val = key.innerText;

//         if(key.classList.contains('del')){
//             display.innerText = display.innerText.slice(0,-1) || '0';
//             return;
//         }

//         if(val === '.' && display.innerText.includes('.')) return;

//         if(display.innerText === '0' && val !== '.'){
//             display.innerText = val;
//         } else {
//             display.innerText += val;
//         }
//     });
// });

// document.getElementById('ok').addEventListener('click', () => {
//     KhpaymentInput.value = display.innerText;
//     keypad.style.display = 'none';
//      calculateTotal();//add this
// });

// document.getElementById('cancel').addEventListener('click', () => {
//     keypad.style.display = 'none';
// });

// // This screen of the US pay
//   const UspaymentInput = document.getElementById('cashUSDPayment');
//   UspaymentInput.addEventListener('click', () => {
//     keypad.style.display = 'flex';
//     display.innerText = UspaymentInput.value || '0';
// });
// // document.querySelectorAll('.key').forEach(key => {
// //     key.addEventListener('click', () => {
// //         let val = key.innerText;

// //         if(key.classList.contains('del')){
// //             display.innerText = display.innerText.slice(0,-1) || '0';
// //             return;
// //         }

// //         if(val === '.' && display.innerText.includes('.')) return;

// //         if(display.innerText === '0' && val !== '.'){
// //             display.innerText = val;
// //         } else {
// //             display.innerText += val;
// //         }
// //     });
// // });
// document.getElementById('ok').addEventListener('click', () => {
//     UspaymentInput.value = display.innerText;
//     keypad.style.display = 'none';
//      calculateTotal();//add this
// });
// document.getElementById('cancel').addEventListener('click', () => {
//     keypad.style.display = 'none';
// });
const KhpaymentInput = document.getElementById('cashKHPayment');
const UspaymentInput = document.getElementById('cashUSDPayment');

const keypad = document.getElementById('keypad');
const display = document.getElementById('display');

let currentInput = null; // IMPORTANT

// When click KH
// 
KhpaymentInput.addEventListener('click', () => {
    keypadMode = "PAYMENT";
    currentInput = KhpaymentInput;
    keypad.style.display = 'flex';
    display.innerText = KhpaymentInput.value || '0';
});


// When click USD
// UspaymentInput.addEventListener('click', () => {
//     currentInput = UspaymentInput;
//     keypad.style.display = 'flex';
//     display.innerText = UspaymentInput.value || '0';
// });
UspaymentInput.addEventListener('click', () => {
    keypadMode = "PAYMENT";
    currentInput = UspaymentInput;
    keypad.style.display = 'flex';
    display.innerText = UspaymentInput.value || '0';
});


// Keypad numbers
document.querySelectorAll('.key').forEach(key => {
    key.addEventListener('click', () => {
        let val = key.innerText;

        if (key.classList.contains('del')) {
    display.innerText = display.innerText.slice(0, -1) || '0';
    return;
}

// 🚫 BLOCK decimal in TABLE mode
if (keypadMode === "TABLE" && val === ".") {
    return; // do nothing
}

// Prevent double decimal (for PAYMENT mode)
if (val === '.' && display.innerText.includes('.')) return;

if (display.innerText === '0' && val !== '.') {
    display.innerText = val;
} else {
    display.innerText += val;
}

    });
});

// OK button
// document.getElementById('ok').addEventListener('click', () => {
//     if (currentInput) {
//         currentInput.value = display.innerText;
//     }
//     keypad.style.display = 'none';
//     calculateTotal();
// });
document.getElementById('ok').addEventListener('click', () => {

    // TABLE MODE
    if (keypadMode === "TABLE") {

        if (display.innerText === "0") {
            alert("Please enter table number");
            return;
        }

        selectedTable = "Table " + display.innerText;

        localStorage.setItem("selectedTable", selectedTable);

        keypad.style.display = "none";

        startOrderScreen();
        return;
    }

    // PAYMENT MODE
    if (keypadMode === "PAYMENT" && currentInput) {
        currentInput.value = display.innerText;
        calculateTotal();
    }

    keypad.style.display = "none";
});


// Cancel button
document.getElementById('cancel').addEventListener('click', () => {
    keypad.style.display = 'none';
});

//  ============================================================================================